import java.util.HashMap;

public interface Game {
    String getCurrentScorePlayer(Player player);
    void updateWithPointWonBy(Player player);
}
