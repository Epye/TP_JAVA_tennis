public interface Score {
    String getScore();
    void winPoint();
    void loosePoint();
    void setWin();
}
